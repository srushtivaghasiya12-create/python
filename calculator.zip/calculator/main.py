from calculator_logic import Calculator

def main():
    calc = Calculator()
    print("--- Professional Python Calculator ---")
    
    try:
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))
        op = input("Choose operation (+, -, *, /): ")

        if op == '+': result = calc.add(num1, num2)
        elif op == '-': result = calc.subtract(num1, num2)
        elif op == '*': result = calc.multiply(num1, num2)
        elif op == '/': result = calc.divide(num1, num2)
        else: result = "Invalid operation"

        print(f"Result: {result}")
    except ValueError:
        print("Error: Invalid numeric input.")

if __name__ == "__main__":
    main()